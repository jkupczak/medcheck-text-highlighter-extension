# medcheck-text-highlighter-extension
